"""11주차 4-2 '검산 표'를 참고한 데이터 검증 스크립트.
실행: python check_data.py
"""
from pathlib import Path
import pandas as pd

HERE = Path(__file__).parent
city = pd.read_csv(HERE / "seoul_child_traffic_city_2010_2025.csv")
district = pd.read_csv(HERE / "seoul_child_traffic_district_2010_2025.csv")
hotspots = pd.read_csv(HERE / "seoul_child_hotspots_2012_2025.csv")

assert city.shape[0] == 16
assert district.shape[0] == 400
assert hotspots.shape[0] == 213
assert district["자치구"].nunique() == 25
assert hotspots[["위도", "경도"]].notna().all().all()
assert hotspots["연도"].between(2012, 2025).all()

for column in ["사고건수", "사망자수", "부상자수"]:
    total = district.groupby("연도")[column].sum().sort_index()
    official = city.set_index("연도")[column].sort_index()
    pd.testing.assert_series_equal(total, official, check_names=False)

assert city.loc[city["연도"] == 2025, "사고건수"].item() == 339
assert hotspots.loc[hotspots["연도"] == 2025].shape[0] == 16
print("[통과] 16년 서울 전체 통계 = 25개 자치구 합계")
print("[통과] 다발지역 213행, 좌표 누락 없음, 2012~2025년")
print("[통과] 2025년 서울 전체 사고건수 339건 / 다발지역 16개 기록")
