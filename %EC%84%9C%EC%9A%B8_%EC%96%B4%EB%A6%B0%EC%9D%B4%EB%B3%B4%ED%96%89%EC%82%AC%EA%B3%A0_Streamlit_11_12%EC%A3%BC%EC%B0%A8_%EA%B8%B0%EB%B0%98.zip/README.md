# 서울시 어린이 보행 교통사고 시공간 분석

## 프로젝트 질문
서울의 어린이 보행 교통사고는 어떻게 변화했으며, 사고 다발지역은 어느 자치구와 장소에 집중되어 있을까?

## 자료
- `seoul_child_traffic_city_2010_2025.csv`: 서울 전체 연도별 어린이보행사고(2010~2025)
- `seoul_child_traffic_district_2010_2025.csv`: 서울 25개 자치구의 연도별 어린이보행사고(2010~2025)
- `seoul_child_hotspots_2012_2025.csv`: 어린이 보행 교통사고 다발지역 선정 기록(2012~2025)
- 출처: 한국도로교통공단 (https://opendata.koroad.or.kr/)

분석 대시보드는 두 데이터셋의 **공통 기간인 2012~2025년**을 기본으로 사용합니다. 2010~2011년은 전체 사고 통계에만 존재합니다.

## 실행
```bash
python -m pip install -r requirements.txt
python check_data.py
python -m streamlit run app.py
```
11주차 수업자료의 `@st.cache_data`, `st.sidebar.multiselect`, `st.sidebar.slider`, `st.sidebar.selectbox`, `st.metric`, `st.plotly_chart`, `st.dataframe`, `st.download_button` 방식으로 구현했습니다.

## GitHub 및 Streamlit Community Cloud 배포
12주차 자료대로 저장소를 **Public**으로 만들고, 이 폴더 안의 파일을 모두 업로드합니다.
1. GitHub에서 `New repository` → `Public` → `Add README`.
2. `Add file` → `Upload files` → `app.py`, `requirements.txt`, `*.csv`, `check_data.py`, `README.md` 업로드.
3. https://share.streamlit.io/ 에서 GitHub 연결 → `Create app`.
4. `Repository`: 계정/저장소, `Branch`: main, `Main file path`: app.py.
5. 공개 URL에서 위젯 동작/숫자/한글/지도 확인.

## 지표 해석의 주의점
- 어린이 보행 교통사고 다발지역은 선정 기준 이상인 지점만 담고 있으며, **전체 사고 위치가 아닙니다**.
- 같은 장소가 여러 연도에 선정되었다면 여러 기록으로 계산합니다. 다발지역 '기록 수'와 고유 장소 수를 혼동하지 마세요.
- 자치구별 건수 비교는 인구·보행량을 통제하지 않았으므로 위험도 순위라고 말하지 않습니다.
- '전체 사고건수'는 데이터 A의 자치구 합계이며, 데이터 B의 다발지역 내 사고건수를 다시 더하지 않습니다.
