# 산업데이터시각화 개인 프로젝트 · 11주차 앱 구조 / 12주차 배포 방식 참고
# 주제: 서울시 어린이 보행 교통사고의 시공간적 분포 분석
from pathlib import Path

import pandas as pd
import plotly.express as px
import streamlit as st

st.set_page_config(
    page_title="서울 어린이 보행 교통사고 분석",
    page_icon="📊",
    layout="wide",
)

HERE = Path(__file__).parent

# ── 11주차 2-1: 파일 경로와 데이터 캐시 ─────────────────────────────
@st.cache_data
def load_data():
    city = pd.read_csv(HERE / "seoul_child_traffic_city_2010_2025.csv")
    districts = pd.read_csv(HERE / "seoul_child_traffic_district_2010_2025.csv")
    hotspots = pd.read_csv(HERE / "seoul_child_hotspots_2012_2025.csv")
    return city, districts, hotspots

city, data, hotspots = load_data()

st.title("서울시 어린이 보행 교통사고 시공간 분석")
st.caption("전체 사고 통계: 2010~2025년 | 사고 다발지역: 2012~2025년 | 출처: 한국도로교통공단")
st.write(
    "**분석 질문:** 서울의 어린이 보행 교통사고는 어떻게 변화했으며, "
    "사고 다발지역은 어느 자치구와 장소에 집중되어 있을까?"
)

# ── 11주차 2-2: 사이드바 위젯 세 개 ─────────────────────────────────
all_districts = sorted(data["자치구"].unique().tolist())
selected_districts = st.sidebar.multiselect(
    "자치구 선택", all_districts, default=all_districts
)
years = st.sidebar.slider(
    "분석 연도 범위 (다발지역과 비교 가능한 기간)", 2012, 2025, (2012, 2025)
)
metric_label = st.sidebar.selectbox(
    "전체 사고 통계의 표시 지표", ["사고건수", "부상자수", "사망자수"]
)
st.sidebar.caption("※ 2010~2011년은 다발지역 데이터가 없어 비교 가능한 공통 기간을 사용합니다.")

# ── 11주차 2-3: 선택 조건으로 두 데이터 모두 필터링 ──────────────────
view = data.loc[
    data["자치구"].isin(selected_districts)
    & data["연도"].between(years[0], years[1])
].copy()

hotspot_view = hotspots.loc[
    hotspots["자치구"].isin(selected_districts)
    & hotspots["연도"].between(years[0], years[1])
].copy()

if view.empty:
    st.warning("표시할 데이터가 없습니다. 사이드바에서 자치구를 하나 이상 선택하세요.")
    st.stop()

# ── 11주차 3-1: 숫자 카드 ─────────────────────────────────────────
c1, c2, c3, c4 = st.columns(4)
c1.metric(f"선택 기간 {metric_label} 합계", f"{view[metric_label].sum():,} " + ("건" if metric_label == "사고건수" else "명"))
c2.metric("전체 사고건수 합계", f"{view['사고건수'].sum():,}건")
c3.metric("사고 다발지역 기록 수", f"{len(hotspot_view):,}개")
c4.metric("선택 자치구 수", f"{view['자치구'].nunique()}개")
st.caption("※ '다발지역 기록 수'는 연도별 선정 기록의 합계로, 서로 다른 장소의 고유 개수가 아닙니다.")

# ── 11주차 3-2: Plotly 차트 ─────────────────────────────────────────
trend = (
    view.groupby("연도", as_index=False)[metric_label]
    .sum()
    .sort_values("연도")
)
fig_trend = px.line(
    trend, x="연도", y=metric_label, markers=True,
    title=f"① 연도별 {metric_label} 변화",
    labels={"연도": "연도", metric_label: "건" if metric_label == "사고건수" else "명"},
)
fig_trend.update_xaxes(dtick=1)
fig_trend.update_layout(hovermode="x unified")

hotspot_trend = (
    hotspot_view.groupby("연도").size()
    .reindex(range(years[0], years[1] + 1), fill_value=0)
    .rename("다발지역기록수")
    .reset_index()
)
fig_hotspot_trend = px.line(
    hotspot_trend, x="연도", y="다발지역기록수", markers=True,
    title="② 연도별 어린이 보행 교통사고 다발지역 기록 수",
    labels={"연도": "연도", "다발지역기록수": "기록 수(개)"},
)
fig_hotspot_trend.update_xaxes(dtick=1)
fig_hotspot_trend.update_layout(hovermode="x unified")

ranking = (
    view.groupby("자치구", as_index=False)[metric_label]
    .sum()
    .sort_values(metric_label, ascending=False)
)
fig_ranking = px.bar(
    ranking, x="자치구", y=metric_label,
    title=f"③ 자치구별 {metric_label} 비교 (선택 기간 합계)",
    labels={"자치구": "자치구", metric_label: "건" if metric_label == "사고건수" else "명"},
)
fig_ranking.update_layout(xaxis_tickangle=-45)

# ── 11주차 3-3: 두 열 배치 ─────────────────────────────────────────
left, right = st.columns(2)
with left:
    st.plotly_chart(fig_trend, use_container_width=True)
with right:
    st.plotly_chart(fig_hotspot_trend, use_container_width=True)
st.plotly_chart(fig_ranking, use_container_width=True)

# 지도: 11주차의 Plotly 차트를 지리 데이터에 확장 적용
st.subheader("④ 어린이 보행 교통사고 다발지역 위치")
if hotspot_view.empty:
    st.info("현재 선택한 자치구와 연도에는 사고 다발지역 기록이 없습니다.")
else:
    fig_map = px.scatter_map(
        hotspot_view,
        lat="위도", lon="경도", size="사고건수", color="사고건수",
        hover_name="장소",
        hover_data={"연도": True, "자치구": True, "사고건수": True,
                    "사상자수": True, "위도": False, "경도": False},
        zoom=10, height=520,
        title="위치별 다발지역 기록 (마커 크기: 해당 기록의 사고건수)",
    )
    fig_map.update_layout(map_style="open-street-map", margin=dict(l=0, r=0, t=35, b=0))
    st.plotly_chart(fig_map, use_container_width=True)

st.caption(
    "주의: 사고 다발지역은 일정 기준에 따라 선정한 곳만 포함합니다. "
    "전체 사고 발생 위치를 의미하지 않으며, 자치구별 단순 사고건수가 위험도를 뜻하지는 않습니다."
)

# ── 11주차 4-1: 표와 CSV 다운로드, 화면과 동일한 view 사용 ────────────
st.subheader("원자료 확인 및 다운로드")
with st.expander("전체 사고 통계: 선택 조건의 행 보기"):
    st.dataframe(view, hide_index=True, use_container_width=True)
    st.download_button(
        "전체 사고 통계 CSV 저장",
        data=view.to_csv(index=False).encode("utf-8-sig"),
        file_name="selected_district_accidents.csv", mime="text/csv",
    )
with st.expander("사고 다발지역: 선택 조건의 행 보기"):
    st.dataframe(hotspot_view, hide_index=True, use_container_width=True)
    st.download_button(
        "사고 다발지역 CSV 저장",
        data=hotspot_view.to_csv(index=False).encode("utf-8-sig"),
        file_name="selected_hotspots.csv", mime="text/csv",
    )

st.markdown("---")
st.write("**공식 출처**")
st.markdown(
    "- [한국도로교통공단 지자체별 대상사고 통계]"
    "(https://opendata.koroad.or.kr/api/selectSttDataSet.do)  "
    "\n- [한국도로교통공단 보행어린이 교통사고 다발지역]"
    "(https://opendata.koroad.or.kr/api/selectChildDataSet.do)"
)
st.caption("전체 사고 통계는 어린이보행사고 유형을 사용했습니다. 비교 가능한 2012~2025년을 기본 분석 범위로 설정했습니다.")
